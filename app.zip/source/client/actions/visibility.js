function toggleVisibility(filter) {
  return {
    type: filter
  }
}

export {
  toggleVisibility
}
