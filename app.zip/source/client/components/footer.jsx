import React, {
  Component
} from 'react'

import './footer.css'

class Footer extends Component{
  render(){
    return (
      <footer
      >
        <p className="Roboto-thin no-select">© Choc-Devs-9k, 2016</p>
      </footer>
    )
  }
}

  export default Footer
