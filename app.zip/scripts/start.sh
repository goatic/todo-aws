#!/bin/bash

npm run build
npm run start

