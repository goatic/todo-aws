#!/bin/bash

killall node
