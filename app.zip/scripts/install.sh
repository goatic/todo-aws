#!/bin/bash

npm install
