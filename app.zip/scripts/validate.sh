#!/bin/bash

echo "the service is running successfully... Or not?"
